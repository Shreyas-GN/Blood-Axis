module.exports=[88411,a=>{"use strict";var b=a.i(82917);a.s([],25477),a.i(25477),a.s(["007bce572f2589d6a3e5372c89525e7b5bc11a353f",()=>b.getProfileAction,"408f0b98bcb3f015bdb2470adce0a4c07ae416d12a",()=>b.updateProfileAction],88411)}];

//# sourceMappingURL=177fe_bloodRelay_frontend__next-internal_server_app_profile_page_actions_3855f7a4.js.map