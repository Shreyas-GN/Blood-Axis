module.exports=[22679,(e,o,d)=>{}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app_api_auth_otp_send_route_actions_5e5ee402.js.map