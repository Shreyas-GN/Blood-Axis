var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/alerts/escalate/route.js")
R.c("server/chunks/[root-of-the-server]__70870c55._.js")
R.c("server/chunks/f725e_next_dist_esm_build_templates_app-route_cc844a44.js")
R.c("server/chunks/f725e_@supabase_supabase-js_dist_index_mjs_2459350f._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_alerts_escalate_route_actions_8c27629e.js")
R.m(64767)
module.exports=R.m(64767).exports
