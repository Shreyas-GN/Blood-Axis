module.exports=[74978,a=>{"use strict";var b=a.i(82917);a.s([],44091),a.i(44091),a.s(["007bce572f2589d6a3e5372c89525e7b5bc11a353f",()=>b.getProfileAction,"408f0b98bcb3f015bdb2470adce0a4c07ae416d12a",()=>b.updateProfileAction],74978)}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app_hospital_dashboard_page_actions_a405eda0.js.map