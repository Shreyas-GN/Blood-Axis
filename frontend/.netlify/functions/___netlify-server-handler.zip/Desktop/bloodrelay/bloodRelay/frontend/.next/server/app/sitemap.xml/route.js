var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__2d24ecd5._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_sitemap_xml_route_actions_6c014cdb.js")
R.m(42082)
module.exports=R.m(42082).exports
