module.exports=[23436,(e,o,d)=>{}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app_favicon_ico_route_actions_c4c5235a.js.map