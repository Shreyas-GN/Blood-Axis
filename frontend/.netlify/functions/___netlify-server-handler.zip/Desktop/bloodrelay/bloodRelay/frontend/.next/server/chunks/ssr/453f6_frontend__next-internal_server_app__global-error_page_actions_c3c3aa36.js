module.exports=[79146,(a,b,c)=>{}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app__global-error_page_actions_c3c3aa36.js.map