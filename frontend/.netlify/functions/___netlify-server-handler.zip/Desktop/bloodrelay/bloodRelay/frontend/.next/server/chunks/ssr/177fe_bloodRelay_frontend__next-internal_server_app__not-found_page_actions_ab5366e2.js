module.exports=[38251,a=>{"use strict";var b=a.i(82917);a.s([],83615),a.i(83615),a.s(["007bce572f2589d6a3e5372c89525e7b5bc11a353f",()=>b.getProfileAction,"408f0b98bcb3f015bdb2470adce0a4c07ae416d12a",()=>b.updateProfileAction],38251)}];

//# sourceMappingURL=177fe_bloodRelay_frontend__next-internal_server_app__not-found_page_actions_ab5366e2.js.map