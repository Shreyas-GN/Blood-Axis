var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/f725e_next_dist_esm_build_templates_app-route_4278ff4e.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_favicon_ico_route_actions_c4c5235a.js")
R.m(29460)
module.exports=R.m(29460).exports
