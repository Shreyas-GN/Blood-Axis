module.exports=[65669,(e,o,d)=>{}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app_api_requests_route_actions_5c8d3d0f.js.map