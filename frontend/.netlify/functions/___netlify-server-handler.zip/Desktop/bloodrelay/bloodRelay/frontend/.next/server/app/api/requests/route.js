var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/requests/route.js")
R.c("server/chunks/[root-of-the-server]__9f140689._.js")
R.c("server/chunks/f725e_@supabase_supabase-js_dist_index_mjs_2459350f._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_requests_route_actions_5c8d3d0f.js")
R.m(67078)
module.exports=R.m(67078).exports
