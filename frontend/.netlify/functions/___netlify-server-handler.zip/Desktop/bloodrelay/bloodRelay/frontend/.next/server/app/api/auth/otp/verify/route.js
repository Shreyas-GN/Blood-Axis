var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/verify/route.js")
R.c("server/chunks/[root-of-the-server]__425a696b._.js")
R.c("server/chunks/f725e_@supabase_supabase-js_dist_index_mjs_2459350f._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_auth_otp_verify_route_actions_b616f6e7.js")
R.m(20141)
module.exports=R.m(20141).exports
