var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__ebf14e6c._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/177fe_bloodRelay_frontend__next-internal_server_app_robots_txt_route_actions_1790d9ec.js")
R.m(22576)
module.exports=R.m(22576).exports
