var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/callback/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/f725e_afa9e807._.js")
R.c("server/chunks/f725e_@supabase_supabase-js_dist_index_mjs_2459350f._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_auth_callback_route_actions_44ef7b5b.js")
R.m(18351)
module.exports=R.m(18351).exports
