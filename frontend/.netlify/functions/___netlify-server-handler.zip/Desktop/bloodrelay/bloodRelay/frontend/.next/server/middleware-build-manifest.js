globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/ef1cb8d2ed963856.js",
    "static/chunks/c5c265ae1438fbe5.js",
    "static/chunks/126c3ef3de542580.js",
    "static/chunks/e16339063dad2eae.js",
    "static/chunks/4dd7c8b8c3cbf66e.js",
    "static/chunks/turbopack-ae4f9b7a6ea8d36b.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];