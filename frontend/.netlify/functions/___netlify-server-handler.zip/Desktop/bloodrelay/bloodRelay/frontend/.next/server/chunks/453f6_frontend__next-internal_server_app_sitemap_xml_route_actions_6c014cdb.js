module.exports=[61640,(e,o,d)=>{}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app_sitemap_xml_route_actions_6c014cdb.js.map