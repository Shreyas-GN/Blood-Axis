module.exports=[32007,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},15638,a=>{"use strict";let b={src:a.i(32007).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=Desktop_bloodrelay_bloodRelay_frontend_src_app_ce975b47._.js.map