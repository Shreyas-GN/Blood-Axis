module.exports=[12163,(e,o,d)=>{}];

//# sourceMappingURL=177fe_bloodRelay_frontend__next-internal_server_app_robots_txt_route_actions_1790d9ec.js.map