module.exports=[96140,a=>{"use strict";var b=a.i(82917);a.s([],73356),a.i(73356),a.s(["007bce572f2589d6a3e5372c89525e7b5bc11a353f",()=>b.getProfileAction,"408f0b98bcb3f015bdb2470adce0a4c07ae416d12a",()=>b.updateProfileAction],96140)}];

//# sourceMappingURL=453f6_frontend__next-internal_server_app_notifications_page_actions_445d0f45.js.map