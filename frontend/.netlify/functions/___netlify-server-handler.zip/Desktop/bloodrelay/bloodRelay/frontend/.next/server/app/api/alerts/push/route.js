var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/alerts/push/route.js")
R.c("server/chunks/[root-of-the-server]__ec7e1f1f._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_alerts_push_route_actions_7155882c.js")
R.m(69580)
module.exports=R.m(69580).exports
