var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/parse-request/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/f725e_next_dist_esm_build_templates_app-route_60cdfb2d.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_ai_parse-request_route_actions_36a93137.js")
R.m(35741)
module.exports=R.m(35741).exports
