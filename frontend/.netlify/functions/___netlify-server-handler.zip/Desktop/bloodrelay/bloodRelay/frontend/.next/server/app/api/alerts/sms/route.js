var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/alerts/sms/route.js")
R.c("server/chunks/[root-of-the-server]__13b8597b._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_alerts_sms_route_actions_f4e135ed.js")
R.m(73907)
module.exports=R.m(73907).exports
