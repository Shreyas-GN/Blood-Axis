var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/otp/send/route.js")
R.c("server/chunks/[root-of-the-server]__668c1c59._.js")
R.c("server/chunks/f725e_@supabase_supabase-js_dist_index_mjs_2459350f._.js")
R.c("server/chunks/[root-of-the-server]__e87637c5._.js")
R.c("server/chunks/453f6_frontend__next-internal_server_app_api_auth_otp_send_route_actions_5e5ee402.js")
R.m(41580)
module.exports=R.m(41580).exports
